n = int(input("Enter number of products: "))
total = 0
max_discount = 500

for i in range(n):
    name = input("Enter product name: ")
    category = input("Enter category (food/clothing/electronics): ")
    price = float(input("Enter price: "))
    quantity = int(input("Enter quantity: "))

    amount = price * quantity

    if category == "food":
        tax = amount * 0.05
    elif category == "clothing":
        tax = amount * 0.05
    else:
        tax = amount * 0.18

    discount = 0
    if amount >= 5000:
        discount = amount * 0.10
    elif amount >= 2000:
        discount = amount * 0.05

    discount = min(discount, max_discount)
    final = amount + tax - discount
    total += final

    print("\nProduct:", name)
    print("Amount:", amount, "Tax:", round(tax, 2))
    print("Discount:", round(discount, 2))
    print("Final Price:", round(final, 2))

print("\nTotal Invoice Amount: Rs.", round(total, 2))