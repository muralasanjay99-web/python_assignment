n = int(input("Enter number of products: "))
target = float(input("Enter target profit percentage: "))

for i in range(n):
    name = input("Enter product name: ")
    material = float(input("Enter material cost: "))
    labour = float(input("Enter labour charges: "))
    wastage = float(input("Enter wastage cost: "))
    machine = float(input("Enter machine cost: "))
    selling = float(input("Enter selling price: "))
    quantity = int(input("Enter quantity produced: "))

    if material < 0 or labour < 0 or wastage < 0 or machine < 0 or selling < 0 or quantity <= 0:
        print("Invalid input")
        continue

    cost = (material + labour + wastage + machine) * quantity
    revenue = selling * quantity
    profit = revenue - cost
    percentage = (profit / cost) * 100 if cost > 0 else 0

    print("\nProduct:", name)
    print("Total Production Cost:", round(cost, 2))
    print("Total Revenue:", round(revenue, 2))
    print("Profit/Loss:", round(profit, 2))
    print("Profit Percentage:", round(percentage, 2), "%")

    if percentage >= target:
        print("Target achieved")
    else:
        print("Target not achieved")