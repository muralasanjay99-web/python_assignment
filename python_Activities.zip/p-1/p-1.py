n = int(input("Enter number of applicants: "))
students = []

for i in range(n):
    name = input("Enter student name: ")
    marks = float(input("Enter aggregate marks: "))
    s1 = float(input("Enter subject 1 marks: "))
    s2 = float(input("Enter subject 2 marks: "))
    attendance = float(input("Enter attendance percentage: "))
    income = float(input("Enter annual family income: "))

    if marks >= 75 and s1 >= 40 and s2 >= 40 and attendance >= 75 and income <= 200000:
        students.append([name, marks, attendance, income])
        print(name, "is eligible")
    else:
        print(name, "is not eligible")

students.sort(key=lambda x: (x[1], x[2], -x[3]), reverse=True)

print("\nScholarship Ranking:")
for i in range(len(students)):
    print(i + 1, students[i][0], students[i][1])

if len(students) > 0:
    print("\nScholarship awarded to:", students[0][0])
else:
    print("\nNo eligible applicants")