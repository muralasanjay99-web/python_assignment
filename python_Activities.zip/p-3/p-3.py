n = int(input("Enter number of patients: "))

for i in range(n):
    name = input("Enter patient name: ")
    consultation = float(input("Enter consultation charges: "))
    diagnostic = float(input("Enter diagnostic charges: "))
    treatment = float(input("Enter treatment charges: "))

    total = consultation + diagnostic + treatment

    if consultation < 0 or diagnostic < 0 or treatment < 0:
        print("Invalid billing charges")
        continue

    if total >= 10000:
        concession = total * 0.10
    elif total >= 5000:
        concession = total * 0.05
    else:
        concession = 0

    final_bill = total - concession

    if final_bill <= 0:
        print("Invalid final bill")
    elif final_bill <= 3000:
        category = "Low Payment"
    elif final_bill <= 10000:
        category = "Medium Payment"
    else:
        category = "High Payment"

    print("\nPatient:", name)
    print("Total Charges:", total)
    print("Concession:", concession)
    print("Final Bill:", final_bill)
    print("Payment Category:", category)