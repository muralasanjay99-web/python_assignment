n = int(input("Enter number of mobile plans: "))
usage = float(input("Enter monthly data usage in GB: "))
calls = float(input("Enter monthly call minutes: "))
budget = float(input("Enter your budget: "))
validity = int(input("Enter required validity in days: "))

best_cost = float("inf")
best_plan = "None"

for i in range(n):
    name = input("Enter plan name: ")
    price = float(input("Enter plan price: "))
    data = float(input("Enter data limit in GB: "))
    minutes = float(input("Enter call limit in minutes: "))
    days = int(input("Enter validity in days: "))
    extra = max(0, usage - data) * 10
    extra += max(0, calls - minutes) * 0.5
    total = price + extra

    print("Plan:", name, "Total Cost:", round(total, 2))

    if total <= budget and days >= validity:
        if total < best_cost:
            best_cost = total
            best_plan = name

print("\nMost Economical Eligible Plan:", best_plan)
if best_plan != "None":
    print("Total Cost:", round(best_cost, 2))
else:
    print("No plan satisfies the given constraints")