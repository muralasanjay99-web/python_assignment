n = int(input("Enter number of employees: "))

for i in range(n):
    name = input("Enter employee name: ")
    basic = float(input("Enter basic pay: "))
    allowance = float(input("Enter allowances: "))
    overtime = float(input("Enter overtime pay: "))
    incentive = float(input("Enter incentives: "))

    if basic < 0 or allowance < 0 or overtime < 0 or incentive < 0:
        print("Invalid salary details")
        continue

    gross = basic + allowance + overtime + incentive

    if gross <= 20000:
        deduction = gross * 0.05
    elif gross <= 50000:
        deduction = 1000 + (gross - 20000) * 0.10
    else:
        deduction = 4000 + (gross - 50000) * 0.15

    net = gross - deduction

    print("\n----- Salary Statement -----")
    print("Employee Name:", name)
    print("Basic Pay:", basic)
    print("Allowances:", allowance)
    print("Overtime:", overtime)
    print("Incentives:", incentive)
    print("Gross Salary:", round(gross, 2))
    print("Deductions:", round(deduction, 2))
    print("Net Salary:", round(net, 2))