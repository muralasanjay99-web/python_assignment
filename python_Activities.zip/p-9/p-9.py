n = int(input("Enter number of expenses: "))
budget = float(input("Enter total travel budget: "))
fee_rate = float(input("Enter conversion fee percentage: "))
total = 0
categories = {}

for i in range(n):
    category = input("Enter expense category: ")
    amount = float(input("Enter expense amount: "))
    rate = float(input("Enter exchange rate to INR: "))

    converted = amount * rate
    fee = converted * fee_rate / 100
    final = converted + fee
    total += final

    if category in categories:
        categories[category] += final
    else:
        categories[category] = final

    print("Category:", category)
    print("Converted Amount: Rs.", round(converted, 2))
    print("Conversion Fee: Rs.", round(fee, 2))
    print("Final Expense: Rs.", round(final, 2))

print("\nTotal Travel Expenses: Rs.", round(total, 2))
print("Travel Budget: Rs.", round(budget, 2))

if total > budget:
    print("Budget exceeded by Rs.", round(total - budget, 2))
else:
    print("Budget remaining: Rs.", round(budget - total, 2))

print("Largest Expense Category:", max(categories, key=categories.get))