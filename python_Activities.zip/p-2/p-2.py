n = int(input("Enter number of months: "))
bills = []

for i in range(n):
    units = float(input("Enter electricity units consumed: "))

    if units <= 100:
        bill = units * 2
    elif units <= 200:
        bill = 100 * 2 + (units - 100) * 3
    elif units <= 300:
        bill = 100 * 2 + 100 * 3 + (units - 200) * 5
    else:
        bill = 100 * 2 + 100 * 3 + 100 * 5 + (units - 300) * 7

    bill += 50

    if units < 100:
        bill -= 20

    bill += bill * 0.05
    bills.append(bill)
    print("Monthly bill:", round(bill, 2))

for i in range(1, n):
    print("Month", i + 1, "bill:", round(bills[i], 2))
    if bills[i] > bills[i - 1] * 1.5:
        print("Unusual increase detected!")
    else:
        print("Normal bill change")

print("Total electricity bill:", round(sum(bills), 2))