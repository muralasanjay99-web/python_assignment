n = int(input("Enter number of passengers: "))

for i in range(n):
    name = input("Enter passenger name: ")
    age = int(input("Enter passenger age: "))
    distance = float(input("Enter travel distance in km: "))
    print("1. Sleeper  2. AC  3. General")
    cls = int(input("Choose travel class: "))
    cancel = input("Cancel ticket? (yes/no): ")

    if cls == 1:
        rate = 1.5
    elif cls == 2:
        rate = 3.0
    else:
        rate = 0.8

    fare = distance * rate

    if age < 5:
        fare = 0
    elif age >= 60:
        fare = fare * 0.8

    fare += 50

    if cancel == "yes":
        fare = fare * 0.5

    if fare < 0 or distance <= 0:
        print("Invalid details")
        continue

    print("\nPassenger:", name)
    print("Distance:", distance, "km")
    print("Travel Class:", cls)
    print("Final Fare: Rs.", round(fare, 2))