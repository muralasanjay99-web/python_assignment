venue = float(input("Enter venue cost: "))
equipment = float(input("Enter equipment cost: "))
catering = float(input("Enter catering cost per participant: "))
transport = float(input("Enter transport cost: "))
certificate = float(input("Enter certificate cost per participant: "))
sponsorship = float(input("Enter sponsorship amount: "))
fee = float(input("Enter registration fee per participant: "))
participants = int(input("Enter expected participants: "))

fixed_cost = venue + equipment + transport
variable_cost = catering + certificate
total_cost = fixed_cost + variable_cost * participants
contribution = fee * participants
shortfall = max(0, total_cost - sponsorship - contribution)

if fee > variable_cost:
    minimum = max(0, int((fixed_cost - sponsorship) / (fee - variable_cost)) + 1)
    if (fixed_cost - sponsorship) % (fee - variable_cost) == 0:
        minimum -= 1
else:
    minimum = -1

print("\nTotal Event Cost:", total_cost)
print("Participant Contributions:", contribution)
print("Sponsorship Amount:", sponsorship)
print("Funding Shortfall:", shortfall)

if minimum == -1:
    print("Break-even is not possible with this registration fee")
else:
    print("Minimum Registrations for Break-even:", minimum)

if contribution + sponsorship >= total_cost:
    print("Event is financially feasible")
else:
    print("Additional funding is required")